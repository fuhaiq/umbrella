
BeginPackage["KernelTools`", {"JLink`"}]

FrontEndRunningQ::usage =
"FrontEndRunningQ[] returns True if a service front end is running, otherwise False."

FrontEndProcessID::usage =
"FrontEndProcessID[] returns the process id of the service front end, or 0 is none is running."

FrontEndMemoryInUse::usage =
"FrontEndMemoryInUse[] returns the memory in use of the service front end, or 0 is none is running."

RunKernelDiagnostics::usage =
"RunKernelDiagnostics[] returns an expression useful for diagnostics."

StringEvaluate::usage =
"StringEvaluate[s] is evaluates the string s an an expression and returns the result as a string.
StringEvaluate effectively simulates the top-level evaluator."

$JavaObjectsTally::usage =
"Tally of currently referenced Java Objects."

IncrementRefCount::usage =
"IncrementRefCount[obj] increments ref count of Java Object obj."

DecrementRefCount::usage =
"DecrementRefCount[obj] decrements ref count of Java Object obj, and releases it when the ref count reaches 0."

ReportJavaObjectsTally::usage =
"ReportJavaObjectsTally[] returns a list of the current tally, along with information about the objects."

$JVM::usage = "The JVM that is used."


(* error *)
$EvaluationError::usage = "Symbol used to signal evaluation errors."

$EvaluationErrorText::usage = ""
$EvaluationErrorType::usage = ""
$EvaluationErrorFatal::usage = ""


`Utility`Initialize::usage = ""
`Utility`CleanupLinks::usage = ""
`Utility`$LinksTimeLimit::usage = ""

`Information`$Version = "KernelTools Version 1.1.1"
`Information`$VersionNumber = 1.1
`Information`$ReleaseNumber = 1
`Information`$CreationID = 10000
`Information`$CreationDate = {2015, 02, 18, 11, 54, 08}

Begin["`Private`"]

$FrontEndLink :=
	Which[
		(* for V 7 *)
		NameQ["System`UseFrontEndDump`$felink"],
		Symbol["System`UseFrontEndDump`$felink"]
		,
		(* for V 6 and before *)
		NameQ["System`Convert`UseFrontEndDump`$felink"],
		Symbol["System`Convert`UseFrontEndDump`$felink"]
		,
		True,
		$Failed
	]

(*
FrontEndRunningQ is a passive way to determine if a service front end is 
running. If one is not running, then one is not started.

This works by checking if a certain symbol is a LinkObject, then
tickling it with LinkReadyQ, and checking its current error.

Some steps are taken to not introduce symbol names that did not exist before,
since this function must work for different versions of Mathematica.

If none of these symbols exist, then either a front end hasn't been started yet,
or the link symbol has changed names yet again, in either case, just return False.
*)
FrontEndRunningQ[] :=
	feRunningQ0[$FrontEndLink]

feRunningQ0[link_LinkObject] := (LinkReadyQ[link];First[LinkError[link]] === 0)
feRunningQ0[_] := False

FrontEndProcessID[] :=
	If[FrontEndRunningQ[],
		(* $ProcessID works for both, but $NotebookProcessID is preferred, to prevent
		confusion with System`$ProcessID *)
		If[$VersionNumber > 5.2,
			Developer`UseFrontEnd[MathLink`CallFrontEnd[FrontEnd`Value["$NotebookProcessID"]]],
			Developer`UseFrontEnd[MathLink`CallFrontEnd[FrontEnd`Value["$ProcessID"]]]
		],
		0
	]

(*
The front end stupidly returns the memory in use as a real
*)
FrontEndMemoryInUse[] :=
	If[$VersionNumber > 5.2 && FrontEndRunningQ[],
		Round[Developer`UseFrontEnd[MathLink`CallFrontEnd[FrontEnd`Value["MemoryInUse"]]]],
		0
	]

(*
do everything we can within M code to cancel the evaluation
*)
KernelTools`Utility`CleanupLinks[] :=
	Module[{links = DeleteCases[Links[], $ParentLink]},
		(*
		remove periodical
		use Quiet here because CleanupLinks[] may be called synchronously, like in destroy()
		*)
		Quiet[Internal`RemovePeriodical[KernelTools`Utility`CleanupLinks[]], Internal`RemovePeriodical::notfound];
		(*
		send Terminate message to all links, and close them
		ignore the warning about LinkInterrupt taking less 2 arguments
		*)
		Scan[(LinkInterrupt[#, 1];LinkClose[#])&, links];
	]

(*
IMPORTANT
Stay in synch with Kernel.java

The CForm around SessionTime[] and TimeUsed[] is to ensure that
the numbers sent are understandable by Java (would use JavaForm if existed).
After 1 million seconds (11.5 days), switches to scientific notation, and 
the 2-dimensonal OutputForm form of 1.*^6 is definitely not understandable
by Java.
*)
RunKernelDiagnostics[] :=
	Module[{tfLink = "TerminateForwardLink" /. ("TerminateOptions" /. SystemOptions["TerminateOptions"])},
		If[MatchQ[$FrontEndLink, _LinkObject] && tfLink =!= $FrontEndLink, 
			SetSystemOptions["TerminateOptions" -> {"TerminateForwardLink" -> $FrontEndLink}];
		];
		ToString /@ {MemoryInUse[], MaxMemoryUsed[], FrontEndProcessID[], FrontEndMemoryInUse[], CForm[SessionTime[]], CForm[TimeUsed[]]}
	]


(*
StringEvaluate basically reimplements the capability of CheckAll to intercept exceptions, because CheckAll does not emit messages.
We need to intercept exceptions, but also let their messages get through.
If there is ever a version of CheckAll that emits messages, then use that
*)
StringEvaluate[s_String, form_:OutputForm] :=
	Module[{res, reaped},
		(*
		quiet Internal`AddPeriodical::timc because $LinksTimeLimit could be negative or 0
		*)
		Quiet[Internal`AddPeriodical[KernelTools`Utility`CleanupLinks[], KernelTools`Utility`$LinksTimeLimit], Internal`AddPeriodical::timc];
		{res, reaped} =
			Reap[
				Catch[
					Sow[
						Catch[
							With[{e = ToExpression[s]},
								ToString[Unevaluated[form[e]]]
							]
							,
							_
							,
							ToString[form[Hold[Throw[##]]]]&
						]
						,
						"StringEvaluate-Handled"
					]
				]
				,
				"StringEvaluate-Handled"
			];
		(*
		quiet Internal`RemovePeriodical::notfound because could have already been removed (by itself)
		*)
		Quiet[Internal`RemovePeriodical[KernelTools`Utility`CleanupLinks[]], Internal`RemovePeriodical::notfound];
		If[reaped == {},
			(*uncaught 1-arg Throw*)
			With[{res = res},
				ToString[form[Hold[Throw[res]]]]
			]
			,
			res
		]
	]

KernelTools`Utility`Initialize[] :=
	Module[{},
		$JVM = GetJVM[InstallJava[]];
		LoadJavaClass[$JVM, "com.wolfram.kerneltools.state.ErrorType"];
		$EvaluationErrorType = ErrorType`NOERROR;
		$EvaluationErrorText = "";
		$EvaluationErrorFatal = False;
		$JavaObjectsTally = {};
	]

IncrementRefCount[obj_] :=
	Module[{pos},
		If[(pos = Position[$JavaObjectsTally[[All,1]], obj]) == {},
			AppendTo[$JavaObjectsTally, {obj, 1}] 
			,
			pos=pos[[1,1]];
			$JavaObjectsTally[[pos,2]]++
		]
	]


DecrementRefCount::j = "Java Object `1` is not in the tally."

DecrementRefCount::z = "Ref count for `1` is already zero."

DecrementRefCount[obj_] :=
	Module[{pos},
		If[(pos = Position[$JavaObjectsTally[[All,1]], obj]) == {},
			Message[DecrementRefCount::j, obj];
			Return[$Failed]
			,
			pos=pos[[1,1]];
			If[$JavaObjectsTally[[pos,2]] == 0,
				Message[DecrementRefCount::z, obj];
				Return[$Failed]
			];
			$JavaObjectsTally[[pos,2]]--;
			If[$JavaObjectsTally[[pos,2]] == 0,
				$JavaObjectsTally = Delete[$JavaObjectsTally, pos];
				ReleaseJavaObject[obj]
			]
		]
	]

ReportJavaObjectsTally[] := {#[[1]], #[[1]]@toString[], #[[2]]}& /@ $JavaObjectsTally

End[]

EndPackage[]
