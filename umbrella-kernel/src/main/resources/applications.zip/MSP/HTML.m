(* :Name: MSP`HTML` *)

(* :Title: Mathematica HTML functions*)

(* :Author: Tom Wickham-Jones *)

(* :Copyright: 
       webMathematica source code (c) 1999-2015,
       Wolfram Research, Inc. All rights reserved.
*)

(* :Mathematica Version: 4.2 *)

(* :Package Version: 1.0 *)

(* :Author:
   Tom Wickham-Jones
   twj@wolfram.com
*)


(*:Summary:
   This package provides Mathematica support for formatting 
   expressions into HTML.
*)



BeginPackage[ "MSP`HTML`"]


HTMLTableForm::usage = "HTMLTableForm[data, opts], formats data into an html table. HTMLTableForm[ data, fun, opts] uses the function fun to format each element."

TableAttributes::usage = "TableAttributes is an option of HTMLTableForm that specifies table attributes to use for the table."

HTMLFormat::usage = "HTMLFormat[expr] formats an expression into HTML such that numbers and powers use superscript notation."

HTMLSelect::usage = "HTMLSelect[options, name] returns an HTML select with the given set of options.
HTMLSelect[options, values, name] returns an HTML select with the given set of options that correspond to the given set of values.
HTMLSelect[options, name, default] sets the default."

HTMLCheckbox::usage = "HTMLCheckbox[name] returns an HTML input tag of type checkbox. HTMLCheckbox[name, True] selects the checkbox."

HTMLCheckBox::usage = "HTMLCheckBox is an obsolete name for HTMLCheckbox."

SelectedValues::usage = "SelectedValues is an option of HTMLSelect which specifies any values that should be selected."

SelectedOptions::usage = "SelectedOptions is an option of HTMLSelect which specifies any options that should be selected."

OptionAttributes::usage = "OptionAttributes is an option of HTMLSelect that specifies attributes for the <option> tags."

HTMLColor::usage = "HTMLColor[col] returns an HTML expression that represents the color col."

HTMLStyle::usage = "HTMLStyle[expr, style], formats expr in style. HTMLStyle[expr, style, fun] uses the function fun to format expr."


Begin[ "`Private`"]


Options[ HTMLTableForm] = 
    { TableHeadings -> None, TableAttributes -> {"border" -> "1"}}

HTMLTableForm[ TableForm[ x_, topts___?OptionQ], opts___?OptionQ] :=
    HTMLTableForm[ TableForm[x, topts], Automatic, opts]


HTMLTableForm[ x_, opts___?OptionQ] := 
    HTMLTableForm[ x, Automatic, opts]
    

HTMLTableForm[ TableForm[ x_, topts___?OptionQ], fmtFun_:Automatic, opts___?OptionQ] :=
    Module[ {headings},
        headings = TableHeadings /. {topts} ;
        If[ ListQ[ headings], 
            HTMLTableForm[ x, fmtFun, TableHeadings -> headings, opts],
            HTMLTableForm[ x, fmtFun, opts]]
        ]


HTMLTableForm[ x_, fmtFunArg_:Automatic, opts___?OptionQ] :=
	Module[{data, res, ncol, nrow, tattrs, fmtFun = fmtFunArg, collabels, rowlabels},
		data = PadData[x];
		nrow = Length[data];
		ncol = Length[Part[data, 1]];
		If[fmtFun === Automatic, fmtFun = autoFmt];
		{rowlabels, collabels} = splitHeadings[TableHeadings /. {opts} /. Options[HTMLTableForm]];
		collabels =
			processHeadings["collabels", collabels, ncol, fmtFun];
		rowlabels =
			processHeadings["rowlabels", rowlabels, nrow, fmtFun];
		tattrs = checkAttrs[TableAttributes /. {opts} /. Options[HTMLTableForm]];
		res = Map[XMLElement["td", {}, {elemFormat[#, fmtFun]}]&, data, {2}];
		If[rowlabels =!= {},
			If[collabels =!= {},
				(* add extra spacer <th/> to allow row labels to align properly *)
				collabels = Prepend[collabels, XMLElement["th", {}, {}]]
			];
			res = Flatten /@ Transpose[{rowlabels, res}]
		];
		res = XMLElement["tr", {}, #]& /@ res;
		If[collabels != {},
			(* http://www.w3.org/TR/html4/struct/tables.html#edef-TH *)
			collabels = {XMLElement["tr", {}, collabels]}
		];
		res = Join[collabels, res];
		res = ExportString[XMLElement["table", tattrs, res], "XML"];
		res
	]


(*
 Map all binary characters except for #x9 | #xA | #xD to Mathematica 
 input form.
*)

BinaryRules =
	{"\000" -> "\\000", "\001" -> "\\001", "\002" -> "\\002", "\003" -> "\\003",
   "\004" -> "\\004", "\005" -> "\\005", "\006" -> "\\006", "\007" -> "\\007",
   "\010" -> "\\010", "\013" -> "\\013", "\014" -> "\\014", "\016" -> "\\016",
   "\017" -> "\\017", "\020" -> "\\020", "\021" -> "\\021", "\022" -> "\\022",
   "\023" -> "\\023", "\024" -> "\\024", "\025" -> "\\025", "\026" -> "\\026",
   "\027" -> "\\027", "\030" -> "\\030", "\031" -> "\\031", "\032" -> "\\032"
	}

fixBinaryChars[ x_] :=
	StringReplace[ x, BinaryRules]

autoFmt[ x_] := If[ StringQ[ x], fixBinaryChars[ x], HTMLFormat[x]]

(*
 If any of x elems are lists then turn all into lists and pad to longest length.
 Else just turn into a list of lists.
*)

PadData[ x_] := PadData[ {{x}}]

PadData[ x_List] :=
    Module[ {len = -1, empty = True},
        Scan[ If[ ListQ[#], len = Max[ len, Length[#]]]&, x] ;
        If[ len === 0, 
            Scan[ If[ ListQ[#] && Length[#] > 0, empty = False]&,x];
            If[ empty, len = -1]] ;
        If[ len === -1,
            Map[ List, x],
            Map[ PadToLength[ #, len]&, x]]
    ]
    
PadToLength[ x_List, len_] := PadRight[ x, len, ""]

PadToLength[ x_, len_] := PadRight[ {x}, len, ""]


elemFormat[ e_, fun_]:=
    Module[ {elem},
        elem = fun[e] ;
        If[ !StringQ[ elem],
            Message[ HTMLTableForm::elem, e]; HTMLFormat[e]] ;
        XML`RawXML[ elem]
        ]


HTMLFormat[e_] := 
    Module[ {ef, subProt},
        AbortProtect[
            Unprotect[ Real];
            Unprotect[ String];
            Unprotect[ Power];
            subProt = Unprotect[ Subscript] ;
            Format[ x_Real, InputForm] := OutputForm[ numFormat[x]] ;
            Format[ x_String, InputForm] := OutputForm[ x] ;
            Format[ Power[ x_, y_], InputForm] := SequenceForm[ x, "HTML`Private`SUPOPEN" ,y, "HTML`Private`SUPCLOSE"] ;
            Format[ Subscript[ x_, y_], InputForm] := SequenceForm[ x, "HTML`Private`SUBOPEN" ,y, "HTML`Private`SUBCLOSE"] ;
            ef = ToString[ e, InputForm] ;
            Unset[ Format[ x_Real, InputForm]] ;
            Unset[ Format[ x_String, InputForm]] ;
            Unset[ Format[ Power[ x_, y_], InputForm]] ;
            Unset[ Format[ Subscript[ x_, y_], InputForm]] ;
            Protect[ Real] ;
            Protect[ String] ;
            Protect[ Power]] ;
            If[ Length[ subProt] === 1, Protect[ Subscript]];
        StringReplace[ ef, $XMLEntityRules]
    ]


numFormat[ e_] := 
    NumberForm[ e, NumberFormat -> 
        (If[#3 === "", #1, #1 <> " " <> #2 <>  "HTML`Private`SUPOPEN" <> #3 <> "HTML`Private`SUPCLOSE"]&)]



$XMLEntityRules =
    {"\"" -> "&quot;", "&" -> "&amp;", "<" -> "&lt;", ">" -> "&gt;" ,
    " " -> "&#160;", "\t" -> "&#160;&#160;&#160;&#160;", 
    "HTML`Private`SUPOPEN" -> "<sup>", 
    "HTML`Private`SUPCLOSE" -> "</sup>",
    "HTML`Private`SUBOPEN" -> "<sub>", 
    "HTML`Private`SUBCLOSE" -> "</sub>" }


splitHeadings[ _] := {{}, {}}

splitHeadings[ { r_List, c_List}] := {r, c}

splitHeadings[ c_List] := {{}, c}


processHeadings[ _, _ , _, _] := {}

processHeadings[ _, {} , _, _] := {}


processHeadings[ tag_, x_List,n_,fun_]:=
  If[Length[x]=!=n,
        Message[ MessageName[ HTMLTableForm, tag], Length[x], n];{},
        Map[XMLElement["th",{},{elemFormat[#,fun]}]&,x]]


checkAttrs[_]:={}

checkAttrs[a:{(_String->_String) ..}]:=a



HTMLTableForm::collabels = "The number of headings, `1`, does not match the number of columns, `2`. Formatting will omit the headings."

HTMLTableForm::rowlabels = "The number of labels, `1`, does not match the number of rows, `2`. Formatting will omit the labels."


HTMLTableForm::elem = "The format function applied to element, `1`, did not return a string."


(*
  HTMLSelect
*)

Options[ HTMLSelect] = {SelectedValues -> {}, SelectedOptions -> {}, OptionAttributes -> {}}


HTMLSelect[opts_List, valsIn_List:{}, name_?AtomQ, options___?OptionQ] := 
    Module[ { opt, val, vals = valsIn, selVals, selOpts, optAttrs, htmlAttrs},
        selVals = normalizeOption[ SelectedValues /. {options} /. Options[ HTMLSelect]] ;
        selOpts = normalizeOption[ SelectedOptions /. {options} /. Options[ HTMLSelect]] ;
        optAttrs = testAttr[ OptionAttributes /. {options} /. Options[ HTMLSelect]] ;
        htmlAttrs = FilterRules[{options}, Except[Options[HTMLSelect]]];
        If[ Length[ vals] =!= Length[ opts], vals = Range[ Length[ opts]]];
        ExportString[
            XMLElement["select", {"name" -> ToString[name], Sequence @@ htmlAttrs},
                Table[
                    opt = toString[ opts[[i]]] ;
                    val = toString[ vals[[i]]] ;
                    XMLElement["option", 
                        Join[ optAttrs,
                        Flatten[{"value"->val,
                            If[ MemberQ[ selOpts, opt] || MemberQ[ selVals, val], "selected" ->"selected", {}]}]],
                            {opt}], 
                    {i, Length[opts]}]], "XML"]
        ]


normalizeOption[ x_] := normalizeOption[ {x}]

normalizeOption[ x_List] := Map[ toString, x]

toString[ x_] := If[ StringQ[ x], x, ToString[x]]

testAttr[ attr:{ _String -> _String...}] := attr

testAttr[ _List] := {}

testAttr[ x_] := testAttr[ {x}]


(*
  HTMLCheckbox
*)


HTMLCheckBox = HTMLCheckbox

HTMLCheckbox[ name_, selected_:False] :=
    ExportString[ 
        XMLElement[ "input", Flatten[{"type" -> "checkbox", 
                                "name" -> ToString[name], 
                                If[TrueQ[ selected], "checked" ->"checked",{}]}], {}], 
        "XML"]


HTMLCheckbox[name_, "on"] := HTMLCheckbox[name, True]


(*
 Generate HTML color specs
*)
HTMLColor[ s_GrayLevel] :=
	HTMLColor[ ToColor[s, RGBColor]]
	
HTMLColor[ s_Hue] :=
	HTMLColor[ ToColor[s, RGBColor]]
	
HTMLColor[ RGBColor[ r_,g_,b_]] :=
	"#" <> formatDigit[r ] <> formatDigit[g] <> formatDigit[b]
	
formatDigit[dIn_] := 
	Module[{d, s},
		d = dIn;
		If[ d > 1., d = 1.] ;
		If[ d < 0., d = 0.] ;
		d = Floor[ d 255];
		s = ToString[BaseForm[d, 16]];
		s = StringDrop[s, {Part[StringPosition[s, "\n"], 1, 1], -1}];
		Switch[
			StringLength[s],
				0, "00",
				1, "0" <> s,
				2, s,
				True, "00"
			]
	]

(*
 Get style functions, at the moment this is only hooked 
 up for colors.
*)
getStyleInformation[ _RGBColor] = {"color", HTMLColor}
getStyleInformation[ _Hue] = {"color", HTMLColor}
getStyleInformation[ _GrayLevel] = {"color", HTMLColor}
getStyleInformation[ _] := $Failed


makeStyleList[ style_] :=
	Module[ {info},
		info = getStyleInformation[ style];
		If[ info == $Failed, Return[{}]];
		{info[[1]] -> info[[2]][ style]}	
	]

(*
 Add a style markup -- at present this is just 
 for text font.
*)

HTMLStyle[ expr_, style_, fmtFunArg_:Automatic] :=
	Module[ {str, fmtFun = fmtFunArg, styleList},
		str = expr;
		If[ fmtFun === Automatic, fmtFun = autoFmt];
		If[ !StringQ[str], str = HTMLFormat[str]];
		styleList = makeStyleList[ style];
		ExportString[ 
        	XMLElement[ "font", styleList, {XML`RawXML[str]}], 
        	"XML"]
        ]


End[]


EndPackage[]



