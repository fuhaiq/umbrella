(* ::Package:: *)

(* This program gets a DataSource Object from the Tomcat context 
 * Equivalent Java code:
 *
 * Context initContext = new InitialContext();
 * Context envContext  = (Context)initContext.lookup("java:/comp/env");
 * dataSource = (DataSource)envContext.lookup("database");	
 * return dataSource.getConnection();
 *
 * environment = "java:/comp/env"
 * name = "database"
 *)
BeginPackage["MSP`Connection`", {"DatabaseLink`", "JLink`"}]
 
OpenDatabaseResource::usage =
""

JNDI::usage =
""

Begin["`Private`"]

Options[OpenDatabaseResource] = Options[OpenSQLConnection]
  
(* Get a SQL Connection using the given JNDI resource
 * (In Tomcat, this is defined within the Context of a given web app).
 *
 *)
OpenDatabaseResource[JNDI[environment_String, name_String], opts:OptionsPattern[]] :=
	Module[{catalog = OptionValue[Catalog],
			timeout = OptionValue[Timeout],
			result, context, envContext, dataSource, connection,
			classname, url, username, password, id, conn},
		JavaBlock[
			Block[{$JavaExceptionHandler = DatabaseLink`SQL`Private`ThrowException},
				result = Catch[
					context = JavaNew["javax.naming.InitialContext"];
					envContext = context@lookup[environment];
					
					dataSource = envContext@lookup[name];
					connection = dataSource@getConnection[];
 				
					connection@setCatalog[ToString[catalog]];

 					(* Get options from resource definition *)
 					classname = dataSource@getDriverClassName[];
 					url = dataSource@getUrl[];
 									
					username = dataSource@getUsername[];
					password = dataSource@getPassword[];

					id = ++DatabaseLink`SQL`Private`$connectionIndex;
					
					(* Set the timeout to the global default if invalid. *)
					If[(!IntegerQ[timeout] && timeout =!= None && timeout =!= Automatic) || timeout < 0,
						timeout = $SQLTimeout;
					];
					
					conn = SQLConnection[
							JDBC[classname, url],
							connection,
							id,
							"Username" -> username,
							"Password" -> password,
							"Catalog"  -> catalog,
							"Timeout"  -> timeout
							(* Uncomment to pass all options to the SQLConnection expression *)
							(* ,opts *)
						];
					
					KeepJavaObject[connection];
												
					conn
        		];
        		result
 			]
 		]
 	]

End[]

EndPackage[]
