(* Paclet Info File *)

(* created 2009/08/28*)

Paclet[
    Name -> "MSP",
    Version -> "3.2.0",
    MathematicaVersion -> "6+",
    Extensions -> 
        {
            {"Application", Root -> "MSP", Context -> "MSP`"}, 
            {"Documentation", Resources -> 
                {"Guides/webMathematica"}
            , Language -> "English"}
        }
]


