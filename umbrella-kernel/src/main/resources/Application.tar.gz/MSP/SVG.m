(* :Name: MSP`SVG` *)

(* :Title: webMathematica SVG functions*)

(* :Author: Tom Wickham-Jones *)

(* :Copyright: 
       webMathematica source code (c) 1999-2013,
       Wolfram Research, Inc. All rights reserved.
*)

(* :Mathematica Version: 4.2 *)

(* :Package Version: 1.0 *)

(* :Author:
   Tom Wickham-Jones
   twj@wolfram.com
*)


(*:Summary:
   This package provides Mathematica support for returning 
   web packages that use SVG.
*)


BeginPackage[ "MSP`SVG`", "MSP`"]


SVGShow::usage = "SVGShow[g] adds an embed tag that references an SVG rendering of the graphics object g. SVGShow[g, size] sets the size of the graphic."

SVGDisplay::usage = "SVGDisplay[ s, {w, h}] adds an embed tag that references the SVG string s, with width w and height h."

$SVGPluginsPage::usage = "$SVGPluginsPage gives the URL for the plugins page used by SVGShow and SVGDisplay."

Begin["`Private`"]

(*
 Default setting is the adobe page.
*)

$SVGPluginsPage = "http://www.adobe.com/svg/viewer/install/"

GetImageSize[ g_] := 
    Module[ {x},
        x = ImageSize/.Options[ g, ImageSize] ;
        If[ ListQ[ x], x, {x, x AspectRatio/.Options[g, AspectRatio]}]
    ]


SetImageSize[ g_]:=
    If[ (ImageSize/.Options[ g, ImageSize]) === Automatic, 
        Show[ g, ImageSize -> 400], g]


SVGAdd[w_,h_,url_] :=
	ExportString[XMLElement["object", {"data" -> url, "width" -> ToString[w], "height" -> ToString[h], "type" -> "image/svg+xml"}, {}], "XML"]


SVGShow[ g_, size_:Automatic] :=
        Module[ {gf = g, x, y},
            {x,y} = 
                If[ MatchQ[ size, {_?Positive, _?Positive}],
                    size,
                    GetImageSize[ SetImageSize[ g]]];
            gf = Show[ g, ImageSize -> {x,y}] ;
            SVGAdd[ x, y, MSPURLStore[ ExportString[ gf, "SVG"], "text/xml"]]
        ]


SVGDisplay[ svg_, {x_, y_}] :=
    SVGAdd[ x,y,MSPURLStore[ svg, "text/xml"]]

End[]

EndPackage[]

